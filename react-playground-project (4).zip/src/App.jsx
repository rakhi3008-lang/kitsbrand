
import React, { useState } from "react";

const brandData = [
  {
    id: "ecorp",
    name: "ECorp",
    colors: ["#2cd0a6", "#ffffff", "#9e9e9e"], // approximate teal/white/gray
  },
  {
    id: "icorp",
    name: "ICorp",
    colors: ["#f9a825", "#ffffff", "#9e9e9e"], // approximate orange/white/gray
  },
  {
    id: "agency",
    name: "The Agency",
    colors: ["#f44336", "#ffffff", "#9e9e9e"], // approximate red/white/gray
  },
];

export default function BrandKits() {
  const [selectedId, setSelectedId] = useState("agency");

  return (
    <>
      <style>{`
        .brand-kits-container {
          width: 320px;
          background: #121212;
          border-radius: 12px;
          padding: 24px 16px;
          color: white;
          font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
          user-select: none;
        }
        h2 {
          font-size: 20px;
          font-weight: 600;
          margin-bottom: 12px;
        }
        .brand-item {
          background: #1e1e1e;
          border-radius: 8px;
          padding: 12px 16px;
          margin-bottom: 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: pointer;
          transition: background-color 0.15s ease;
        }
        .brand-item:hover {
          background: #272727;
        }
        .brand-left {
          display: flex;
          align-items: center;
        }
        input[type="checkbox"] {
          appearance: none;
          width: 20px;
          height: 20px;
          border: 2px solid #666;
          border-radius: 4px;
          margin-right: 12px;
          position: relative;
          background: transparent;
          cursor: pointer;
          outline: none;
          transition: background-color 0.15s ease, border-color 0.15s ease;
        }
        input[type="checkbox"]:checked {
          background-color: #7c4dff;
          border-color: #7c4dff;
        }
        /* Tick mark for checkbox */
        input[type="checkbox"]:checked::after {
          content: "";
          position: absolute;
          left: 5px;
          top: 2px;
          width: 6px;
          height: 12px;
          border: solid white;
          border-width: 0 2px 2px 0;
          transform: rotate(45deg);
        }
        .brand-circles {
          display: flex;
          margin-right: 12px;
        }
        .circle {
          width: 14px;
          height: 14px;
          border-radius: 50%;
          border: 1px solid #333;
        }
        .circle + .circle {
          margin-left: 6px;
        }
        .brand-name {
          font-size: 14px;
          font-weight: 500;
          white-space: nowrap;
        }
        .settings-btn {
          color: #999;
          cursor: pointer;
          padding: 6px;
          border-radius: 6px;
          transition: background-color 0.15s ease, color 0.15s ease;
          display: flex;
          align-items: center;
        }
        .settings-btn:hover {
          background-color: #333;
          color: white;
        }
        /* Purple highlight border for selected */
        .brand-item.selected input[type="checkbox"] {
          background-color: #7c4dff;
          border-color: #7c4dff;
        }
      `}</style>

      <div className="brand-kits-container" role="list" aria-label="Brand Kits">
        <h2>Brand Kits</h2>

        {brandData.map(({ id, name, colors }) => (
          <label
            key={id}
            htmlFor={`brand-checkbox-${id}`}
            className={`brand-item ${selectedId === id ? "selected" : ""}`}
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === " " || e.key === "Enter") {
                setSelectedId(id);
                e.preventDefault();
              }
            }}
          >
            <div className="brand-left">
              <input
                type="checkbox"
                id={`brand-checkbox-${id}`}
                checked={selectedId === id}
                onChange={() => setSelectedId(id)}
                aria-checked={selectedId === id}
                tabIndex={-1} // keyboard handled on label container
              />
              <div className="brand-circles" aria-hidden="true">
                {colors.map((color, i) => (
                  <span
                    key={i}
                    className="circle"
                    style={{ backgroundColor: color }}
                  ></span>
                ))}
              </div>
              <span className="brand-name">{name}</span>
            </div>
            <button
              type="button"
              className="settings-btn"
              aria-label={`Settings for ${name} brand kit`}
              onClick={(e) => {
                e.stopPropagation();
                alert(`Open settings for ${name}`);
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                height="18"
                viewBox="0 0 24 24"
                width="18"
                fill="currentColor"
              >
                <path d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 00.11-.6l-1.92-3.32a.5.5 0 00-.6-.22l-2.39.96a7.007 7.007 0 00-1.62-.94l-.36-2.54a.5.5 0 00-.5-.42h-3.84a.5.5 0 00-.5.42l-.36 2.54c-.6.26-1.17.6-1.62.94l-2.39-.96a.5.5 0 00-.6.22l-1.92 3.32a.5.5 0 00.11.6l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.5.5 0 00-.11.6l1.92 3.32a.5.5 0 00.6.22l2.39-.96c.45.34 1.02.68 1.62.94l.36 2.54a.5.5 0 00.5.42h3.84a.5.5 0 00.5-.42l.36-2.54a7.007 7.007 0 001.62-.94l2.39.96a.5.5 0 00.6-.22l1.92-3.32a.5.5 0 00-.11-.6l-2.03-1.58zm-7.14 2.56a3 3 0 113-3 3 3 0 01-3 3z" />
              </svg>
            </button>
          </label>
        ))}
      </div>
    </>
  );
}